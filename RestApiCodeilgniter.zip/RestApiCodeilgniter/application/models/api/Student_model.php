<?php 


class Student_model extends CI_Model
{
	
	function __construct()
	{
		# code...
		parent::__construct();
		$this->load->database();
	}

	public function get_students(){
		$query = $this->db->select('*')	
				->from('tbl_students')
				->get();
		return $query->result();		
	}

	public function insert_student($data = array()){
		return $this->db->insert("tbl_students",$data);
	}

	public function delete_student($student_id){
		//delete method
		$this->db->where("id", $student_id);
		return $this->db->delete("tbl_students");
	}

	public function update_student_information($id, $info){
		$update = $this->db->where("id", $id)
				->update("tbl_students", $info);
		if ($update) {
			# code...
			return true;
		}else{
			return false;
		}		
	}


}

?>