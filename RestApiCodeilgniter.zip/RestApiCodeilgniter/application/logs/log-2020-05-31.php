<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-31 17:34:45 --> 404 Page Not Found: Api\student/index
ERROR - 2020-05-31 17:34:47 --> 404 Page Not Found: Api\student/index
ERROR - 2020-05-31 17:34:47 --> 404 Page Not Found: Api\student/index
ERROR - 2020-05-31 17:34:47 --> 404 Page Not Found: Api\student/index
ERROR - 2020-05-31 17:34:47 --> 404 Page Not Found: Api\student/index
ERROR - 2020-05-31 17:34:47 --> 404 Page Not Found: Api\student/index
ERROR - 2020-05-31 17:35:09 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:35:10 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:35:11 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:35:11 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:35:11 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:35:11 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:35:12 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:35:12 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:35:12 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:35:19 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:35:20 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:35:20 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:35:20 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:35:20 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:35:21 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:35:21 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:35:57 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:36:05 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:36:06 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:39:04 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:39:07 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:39:07 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:39:07 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:39:07 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:39:38 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:39:39 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:39:39 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:39:39 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:39:40 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:39:40 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:39:40 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:39:56 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:39:57 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:39:57 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:39:58 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:40:07 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:40:08 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:40:08 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:40:08 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:40:08 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:40:09 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:40:17 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:40:17 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:40:18 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:40:18 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:40:18 --> 404 Page Not Found: /index
ERROR - 2020-05-31 17:41:46 --> 404 Page Not Found: /index
ERROR - 2020-05-31 18:08:52 --> 404 Page Not Found: /index
ERROR - 2020-05-31 18:23:18 --> Severity: error --> Exception: syntax error, unexpected '0' (T_LNUMBER), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xaamppLatest\htdocs\RestApiCodeilgniter\application\controllers\api\Student.php 45
ERROR - 2020-05-31 18:24:07 --> Query error: Table 'codeigniter_rest_api.tbl_student' doesn't exist - Invalid query: SELECT *
FROM `tbl_student`
ERROR - 2020-05-31 18:30:47 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xaamppLatest\htdocs\RestApiCodeilgniter\application\controllers\api\Student.php 11
ERROR - 2020-05-31 18:31:11 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model D:\xaamppLatest\htdocs\RestApiCodeilgniter\system\core\Loader.php 348
ERROR - 2020-05-31 18:31:37 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model D:\xaamppLatest\htdocs\RestApiCodeilgniter\system\core\Loader.php 348
ERROR - 2020-05-31 18:31:49 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model D:\xaamppLatest\htdocs\RestApiCodeilgniter\system\core\Loader.php 348
ERROR - 2020-05-31 18:32:09 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model D:\xaamppLatest\htdocs\RestApiCodeilgniter\system\core\Loader.php 348
ERROR - 2020-05-31 18:33:26 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model D:\xaamppLatest\htdocs\RestApiCodeilgniter\system\core\Loader.php 348
ERROR - 2020-05-31 18:34:58 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model D:\xaamppLatest\htdocs\RestApiCodeilgniter\system\core\Loader.php 348
ERROR - 2020-05-31 18:35:43 --> Severity: Notice --> Undefined variable: query D:\xaamppLatest\htdocs\RestApiCodeilgniter\application\controllers\api\Student.php 47
ERROR - 2020-05-31 18:35:44 --> Severity: error --> Exception: Call to a member function result() on null D:\xaamppLatest\htdocs\RestApiCodeilgniter\application\controllers\api\Student.php 47
ERROR - 2020-05-31 18:36:31 --> Severity: error --> Exception: Call to a member function result() on array D:\xaamppLatest\htdocs\RestApiCodeilgniter\application\controllers\api\Student.php 47
ERROR - 2020-05-31 18:38:32 --> Severity: Notice --> Undefined property: Student::$s D:\xaamppLatest\htdocs\RestApiCodeilgniter\application\controllers\api\Student.php 44
ERROR - 2020-05-31 18:38:32 --> Severity: error --> Exception: Call to a member function get_students() on null D:\xaamppLatest\htdocs\RestApiCodeilgniter\application\controllers\api\Student.php 44
ERROR - 2020-05-31 18:43:16 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Student' does not have a method 'index_get' D:\xaamppLatest\htdocs\RestApiCodeilgniter\application\libraries\REST_Controller.php 739
ERROR - 2020-05-31 18:45:24 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Student' does not have a method 'index_get' D:\xaamppLatest\htdocs\RestApiCodeilgniter\application\libraries\REST_Controller.php 739
ERROR - 2020-05-31 19:03:17 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xaamppLatest\htdocs\RestApiCodeilgniter\application\controllers\api\Student.php 45
