<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-03 13:28:53 --> 404 Page Not Found: /index
ERROR - 2020-06-03 14:12:48 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xaamppLatest\htdocs\RestApiCodeilgniter\application\controllers\api\Student.php 49
ERROR - 2020-06-03 14:15:01 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xaamppLatest\htdocs\RestApiCodeilgniter\application\controllers\api\Student.php 49
ERROR - 2020-06-03 14:20:17 --> 404 Page Not Found: /index
ERROR - 2020-06-03 14:20:20 --> 404 Page Not Found: /index
ERROR - 2020-06-03 15:36:49 --> 404 Page Not Found: /index
ERROR - 2020-06-03 15:42:29 --> 404 Page Not Found: /index
ERROR - 2020-06-03 15:42:50 --> Unable to load the requested class: Security
ERROR - 2020-06-03 15:45:45 --> Unable to load the requested class: Security
