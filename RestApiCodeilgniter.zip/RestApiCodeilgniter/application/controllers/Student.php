<?php 
	
	require APPPATH.'libraries/REST_Controller.php';


	class Student extends REST_Controller
	{
		public function __construct(){
			parent::__construct();
			$this->load->model(array("api/student_model"=>'sm'));
			$this->load->library(array("form_validation"));
			$this->load->helper("security");
		}
		
		/* 
		  INSERT : POST REQUEST TYPE
		   UPDATE : PUT REQUEST TYPE
		   DELETE : DELETE REQUEST TYPE
		   LIST   : GET REQUEST TYPE
		*/

		 

		 //POST <project_url >/index.php/student  
		public function index_post(){ 
			//insert data method 

			//print_r($this->input->post());die;

			//Collectiong form data input
			$name     = $this->security->xss_clean($this->input->post("name"));
			$email    = $this->security->xss_clean($this->input->post("email"));
			$mobile   = $this->security->xss_clean($this->input->post("mobile"));
			$course   = $this->security->xss_clean($this->input->post("course"));


			//form validation for input
			$this->form_validation->set_rules("name", "Name" ,"required");
			$this->form_validation->set_rules("email", "Email" ,"required|valid_email");
			$this->form_validation->set_rules("mobile", "Mobile" ,"required");
			$this->form_validation->set_rules("course", "Course" ,"required");


			//Checking form submission have any error are not
			if ($this->form_validation->run() === FALSE) {
				# code...
				//We have some errors
				$this->response(array(
					"status" => 0,
					"message" => "All fields are Needed"
				),REST_Controller::HTTP_NOT_FOUND);
			}else{

				if (!empty($name) && !empty($email) && !empty($mobile) && !empty($course)) {
				# all value are available 
				$student  = array(

					"name"   => $name,
					"email"  => $email,
					"mobile" => $mobile,
					"course" => $course
				);
				if($this->sm->insert_student($student)){
					$this->response(array(
						"status"  => 1,
						"message" => "Studetns has been Created"
					), REST_Controller::HTTP_OK);
				}else{
					$this->response(array(
						"status"  => 0,
						"message" => "Failed to create Student"
					), REST_Controller::HTTP_INTERNAL_SERVER_ERROR);
				}

			}else{
				//we have some empty field

				$this->response(array(
					"status"   => 0,
					"message"  => "All fields are Needed"
				), REST_Controller::HTTP_NOT_FOUND);
			}

			}

			/*$data      = json_decode(file_get_contents("php://input"));

			$name      = isset($data->name) ? $data->name: "";
			$email     = isset($data->email) ? $data->email: "";
			$mobile    = isset($data->mobile) ? $data->mobile: "";
			$course    = isset($data->course) ? $data->course: ""; */

			
		
		}

		//PUT <project_url >/index.php/student
		public function index_put(){
			//update data method
			$data  = json_decode(file_get_contents("php://input"));
			if (isset($data->id) && isset($data->name) && isset($data->email) && isset($data->mobile) && isset($data->course)) {
				# code...
				$student_id   = $data->id;
				$student_info = array(
					"name"    => $data->name,
					"email"    => $data->email,
					"mobile"    => $data->mobile,
					"course"    => $data->course
				);
				if ($this->sm->update_student_information($student_id, $student_info)) {
					# code...
					$this->response(array(
						"status"  => 1,
						"message" => "Student data updated Successfully"
					), REST_Controller::HTTP_OK);
				}else{
					$this->response(array(
						"status"  => 0,
						"message" => "Failed to update student data"
					), REST_Controller::HTTP_INTERNAL_SERVER_ERROR);
				}
			}else{
				$this->response(array(
					"status"   => 0,
					"message"  => "All fields are Needed",
				), REST_Controller::HTTP_NOT_FOUND);
			}
		}

		//DELETE <project_url >/index.php/student
		public function index_delete(){
			//delete data method 
			$data = json_decode(file_get_contents("php://input"));
			$student_id   = $this->security->xss_clean($data->student_id);
			if ($this->sm->delete_student($student_id)) {
				# return true
				$this->response(array(
					"student" =>1,
					"message" => "Student has been deleted"
				), REST_Controller::HTTP_OK);

			}else{
				//return false
				$this->response(array(
					"student" =>0,
					"message" => "Failed to delete Student"
				), REST_Controller::HTTP_NOT_FOUND); 
			}
		}

		//GET<project_url >/index.php/student
		public function index_get(){
			//List data method 
			//echo "This is GET method";
			

			$student = $this->sm->get_students();

				//print_r($query->result());
				if (count($student) > 0) {
					# code...
					$this->response(array(
						"status"    => 1,
						"message"   => "Studetns Found",
						"data"      => $student
				  	),REST_Controller::HTTP_OK);
				}else{
					$this->response(array(
					"status"    => 0,
					"message"   => "NO Studetns Found",
					"data"      => $student
				),REST_Controller::HTTP_NOT_FOUND);
				}
				
		}
	}	



?>